# ComputationalApps
school mini-project


1. first click the select file button and select the related file.
2. wait till the programm has parsed the file (loading view is displayed then)
3. when done select a building
4. select a date and time when you want to book a classroom
5. display will show the available and not available classroom that you can book
6. hover on a classroom and find out which activities are bussy within the selected book time