package timetableapp.util.state;

public class ViewStates {
    public static final int LoadView = 0;
    public static final int MainView = 1;
    public static final int DataView = 2;
    
}
